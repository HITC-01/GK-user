# Getting Started
* __Note:__ Nodemon should be installed globally.
* Open a terminal instance for every service and one for the proxy.
* Run 'npm install' for every service and the proxy.
* Run 'npm run build' for every service to create a bundle.js file.
* Run 'npm start' for every service and the proxy.
* In a browser navigate to localhost:3000
