import CountDown from './components/countdown.jsx';

window.CountDown = CountDown;