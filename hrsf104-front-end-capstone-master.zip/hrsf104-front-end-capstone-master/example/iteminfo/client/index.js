import Info from './components/iteminfo.jsx';

window.Info = Info;