import Related from './components/relateditems.jsx';

window.Related = Related;