import Reviews from './components/reviews.jsx';

window.Reviews = Reviews;